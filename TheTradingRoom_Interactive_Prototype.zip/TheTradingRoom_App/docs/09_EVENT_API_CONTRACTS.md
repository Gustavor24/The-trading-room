# 09 — Contratos de API, eventos y entidades

## API mínima
GET /api/discovery/agents; GET /api/discovery/strategies; POST /api/discovery/research (idempotency key); GET /api/discovery/jobs/{id}; POST /api/discovery/jobs/{id}/cancel; WS /api/discovery/events.
GET /api/research/cycles; GET /api/research/quotas; GET /api/experiments/{id}; GET /api/strategies/{id}/validations; GET /api/paper/positions; GET /api/paper/orders; GET /api/risk/status; POST /api/risk/kill-switch (autenticado). Ningún endpoint live.

## Evento base JSON
```json
{
  "event_id": "uuid",
  "event_type": "RESEARCH_STARTED",
  "occurred_at": "2026-11-02T12:00:00Z",
  "correlation_id": "uuid",
  "job_id": "job_001",
  "agent_id": "A02",
  "strategy_id": null,
  "environment": "paper",
  "payload": {"status": "researching", "progress": 15}
}
```

## Estado del agente
`idle|researching|analyzing|completed|waiting_approval|error`. Campos: agent_id, role, status, job_id, progress, current_task, last_updated, error. Demo con flag `is_demo`.

## Estado de estrategia
`DISCOVERED|CODING|BACKTESTING|VALIDATING|AUDITING|PAPER_APPROVED|PAPER_ACTIVE|REJECTED|FAILED|PAUSED|ARCHIVED`.

## Tablas esenciales
`research_cycles` (cycle_id, scheduled_for, status); `hypothesis_quota` (day_utc, reserved_count); `hypotheses` (id, fingerprint, source, parent_id, created_at); `strategy_versions` (strategy_id, version, code_hash, params_hash); `datasets` (id, provider, version_hash, available_at); `experiments` (id, strategy_version, dataset_hash, costs, seed, metrics, status); `validation_checks` (experiment_id, check_id, pass, evidence_uri); `promotion_decisions` (strategy_version, decision, evidence_hash, actor, timestamp); `paper_orders`, `paper_fills`, `paper_positions`, `audit_events`.

## Robustez
RBAC y auth, rate limits, event schema validation, idempotency, optimistic locking, transaction boundaries, dead letter queues, log correlation y recuperación tras caídas. Diseñar endpoints de órdenes paper detrás del gateway interno y no exponerlos al LLM.
