# 02 — Brokers, Market Data e Integraciones

## Forex — OANDA Practice (candidato preferido)
- API REST v20 + streaming; ambiente Practice separado de live.
- Instrumentos iniciales EUR_USD y GBP_USD.
- Verificar disponibilidad por jurisdicción, autenticación, límites de tasa, spread, precisión, sesiones, horarios y reglas de ejecución.
- Documentación: https://developer.oanda.com/rest-live-v20/development-guide/

## Crypto — Kraken (datos) + simulador interno (paper)
- REST/WebSocket para datos BTC/USD y ETH/USD, sujeto a permisos y disponibilidad.
- Simulador paper propio para órdenes y fills, con spread, fees, profundidad, latencia, slippage y órdenes parciales.
- Kraken CLI/MCP puede ser útil para prototipos, pero no sustituye un gateway validado.
- https://docs.kraken.com/api/
- https://github.com/krakenfx/kraken-cli

## Alternativas
- Alpaca Crypto paper: https://docs.alpaca.markets/us/docs/trading-api
- Coinbase Advanced Trade: https://www.coinbase.com/developer-platform/products/advanced-trade-api

## Diseño de adaptadores
`MarketDataAdapter`: instruments, historical_bars, stream_quotes, health, metadata.
`PaperBrokerAdapter`: get_account, get_positions, get_orders, submit_paper_order, cancel_paper_order, reconcile, health.
No implementar `LiveBrokerAdapter` en v1. El runtime debe rechazar entornos no-paper.

## Data contract
venue, symbol, asset_class, timeframe, timestamp_utc, bid, ask, last, volume, provider, ingested_at, available_at, dataset_version, quality_flags. Conservar raw y normalizado. Controlar UTC/DST, calendario Forex, 24/7 Crypto, outliers, duplicados, datos faltantes, revisiones, point-in-time, gaps, delistings y fees. En backtesting evitar lookahead y uso de datos no disponibles al momento.

## Investigación externa
Fuentes de noticias/calendarios sólo con licencia apropiada y registro de timestamp de publicación. Verificar cambios de API, políticas de uso y elegibilidad antes de conectar.
