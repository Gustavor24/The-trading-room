# 08 — Roadmap de implementación

## Fase 0 — Repositorio y contratos
Inspección, CLAUDE.md, configuración, monorepo, Docker Compose, .env.example, migrations, schemas, CI, tests base y threat model. Entregable: proyecto arranca localmente y test suite mínima.

## Fase 1 — UI 3D (estimación previa 2–3 semanas)
HQ shell, navegación Explore/Operate, Strategy Discovery vertical slice con 3 agentes mock, 5 pantallas, HUD, overlays, estados demo y eventos. Medir rendimiento.

## Fase 2 — Datos (2–4 semanas)
OANDA Practice (si elegible), Kraken market data, normalización, series históricas versionadas, calidad y observabilidad. Tests de reconexión y datos corruptos.

## Fase 3 — Quant y agentes (3–5 semanas)
Scheduler UTC, cuota diaria, workers, dedupe, Claude API, sandbox de código, backtesting, experiment tracking, reproducibilidad.

## Fase 4 — Validación y paper (3–4 semanas de desarrollo más evaluación)
Walk-forward, stress, auditoría, Promotion Gate, Risk Engine, OANDA Practice paper, Crypto paper simulator, reconciliación y notificaciones.

## Fase 5 — Evaluación prolongada
Comparar resultados paper con backtests, costos, degradación, fiabilidad, incidentes y falsos positivos. No activar live. Duraciones estimadas, no compromisos.

## Presupuesto preliminar no verificado
Cloud $25–100/mes; Claude API $30–200+; DB $0–50; datos $0–250+; monitoreo $0–50. Rango orientativo total $55–650+/mes, no incluye desarrollo ni trading fees. Research budget inicial $5/día, $100/mes (límites propuestos, ajustables).

## Definition of Done
Cada fase requiere código ejecutado, tests reales, logs y demostración reproducible; documentar integraciones no verificadas. Nunca reportar funcionalidad como completa si sólo existe documentación o mock.
