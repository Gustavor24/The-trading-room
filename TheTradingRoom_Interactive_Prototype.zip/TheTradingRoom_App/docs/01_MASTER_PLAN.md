# 01 — Project Master Plan

## Visión
Una oficina virtual 3D que represente una firma de investigación cuantitativa con agentes IA, monitoreo de mercados, backtesting, validación, ejecución simulada y seguimiento de resultados. El usuario actúa como director y puede inspeccionar cualquier agente, trabajo o decisión.

## Alcance inicial
- Forex EUR/USD y GBP/USD; Crypto BTC/USD y ETH/USD.
- Cuatro familias: momentum, trend following, mean reversion y volatility breakout.
- Dos horizontes: day y swing; definir por estrategia intervalos, sesiones y reglas de ejecución.
- Investigación autónoma programada y activación por eventos, no LLMs activos permanentemente.
- Evaluación histórica y paper trading sin fondos reales.

## Arquitectura
Frontend Next.js + React + TypeScript + React Three Fiber + Drei + Tailwind + Zustand; vistas 3D y dashboards HTML 2D. Backend Python FastAPI, Claude API + LangGraph, Celery + Redis, PostgreSQL, WebSocket, artefactos Parquet, Docker Compose. VectorBT o Backtrader para backtests, pytest para pruebas. Prometheus/Grafana opcionales para observabilidad.

## Flujo de datos
Proveedores de mercado -> normalización/calidad -> almacenamiento versionado -> escáner cuantitativo -> orquestador -> agentes -> código en sandbox -> backtest -> validación -> auditoría -> Promotion Gate determinista -> paper execution gateway -> métricas y notificaciones -> interfaz 3D/2D.

## Separación de responsabilidades
Claude Code desarrolla y mantiene código. Claude API asiste a investigación, hipótesis y análisis de evidencia. Workers cuantitativos calculan señales y métricas. El Risk Engine y Execution Gateway nunca dependen de una respuesta libre del LLM para autorizar operaciones.

## Producto
Dos modos: Explore (recorrido 3D) y Operate (paneles funcionales 2D). Todas las salas y avatares muestran estado del backend, y los datos de ejemplo se etiquetan DEMO.
