# 10 — Decisiones, propuestas y preguntas pendientes

## Aprobado por el usuario
- Proyecto llamado The Trading Room / AI Trading Headquarters 3D.
- Forex y Crypto, day y swing.
- Agentes deben encontrar estrategias por sí mismos.
- Investigación cada 6 horas UTC y máximo 10 nuevas hipótesis diarias.
- Auto-promoción a paper trading tras validación: true.
- Notificaciones: true.
- Live trading: false.
- Experiencia de oficina 3D con salas y agentes, más dashboards funcionales.
- Portabilidad para que otra persona implemente el mismo proyecto en su Claude Code.

## Propuestas técnicas, NO decisiones definitivas
- OANDA Practice Forex; Kraken market data y simulador paper Crypto; Alpaca/Coinbase como alternativas.
- React Three Fiber/Next.js + FastAPI/Celery/Redis/PostgreSQL/LangGraph.
- Símbolos iniciales EUR_USD, GBP_USD, BTC/USD, ETH/USD.
- Límites 0.5% riesgo/trade, 2% pérdida diaria, 3 posiciones, 100% nocional; presupuestos $5/día y $100/mes; concurrencia 2/2.
- Umbrales cuantitativos de promoción aún por fijar antes de evaluar estrategias.

## Por verificar/decidir
- Disponibilidad y elegibilidad real de brokers para el operador, restricciones jurisdiccionales.
- Capital inicial paper, apalancamiento, tipos de orden y especificaciones exactas de instrumentos.
- Históricos, licencias, cobertura, costes y granularidad intradía.
- Destino de notificaciones (in-app, email, etc.) y canales autorizados.
- Infraestructura y límites mensuales efectivos.
- Criterios cuantitativos pre-registrados de aprobación por familia y ventana.
- Nivel de detalle visual, assets 3D/licencias, preferencias de avatares.
- Mecanismo de conexión a Notion del receptor: este ZIP funciona sin acceso a Notion.

## Advertencia
No se ha creado software funcional en este paquete. No se han probado brokers ni APIs, no existen resultados de backtesting, no hay dinero real ni órdenes activas.
