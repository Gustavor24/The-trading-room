# 07 — Validación, riesgo y paper trading

## Promotion Gate obligatorio
- Pruebas unitarias y reproducibilidad.
- Calidad de datos, timestamps point-in-time, ausencia de lookahead.
- Simulación realista de fees, spreads, slippage y órdenes parciales.
- Periodos in-sample/out-of-sample; walk-forward; stress testing; sensibilidad de parámetros.
- Sesgos de selección y sobreajuste; número suficiente de operaciones; estabilidad por régimen.
- Auditoría independiente, versión de código/datos congelada y límites de riesgo verificados.
- Umbrales predefinidos por familia ANTES del backtest; falta de evidencia => no promover.

## Estados
DISCOVERED -> CODING -> BACKTESTING -> VALIDATING -> AUDITING -> PAPER_APPROVED -> PAPER_ACTIVE. Alternativas REJECTED, FAILED, PAUSED, ARCHIVED. La promoción es una transacción idempotente auditada. Cualquier modificación exige revalidación.

## Paper execution
OANDA Practice para Forex si la cuenta de práctica está disponible. Crypto mediante simulador interno alimentado por datos Kraken (alternativa Alpaca paper si se verifica). No tratar el simulador como equivalente exacto al mercado real.

## Límites iniciales ilustrativos
Riesgo planificado por operación 0.5% del capital paper; pérdida diaria 2%; máximo 3 posiciones abiertas; exposición total nocional hasta 100% como límite preliminar sujeto a definición para Forex y cualquier apalancamiento. Límites por mercado/símbolo, correlación, órdenes pendientes, tamaño mínimo y margen deben parametrizarse y probarse. Los stops no garantizan pérdidas máximas ante gaps/slippage.

## Fail closed
Si datos stale, reloj desincronizado, broker desconectado, límites excedidos, orden duplicada, riesgo no computable o posiciones no reconciliadas => bloquear nuevas órdenes. Kill switch persistente, cancelación de pendientes cuando proceda, audit trail, alertas críticas y recuperación manual segura.

## Seguridad live
`live_trading_enabled=false`. Sin rutas, credenciales ni adaptadores de trading real. No desbloquear live mediante prompt. Futuro proyecto independiente con aprobación explícita y revisión técnica/regulatoria.

## Notificaciones
strategy_approved, strategy_rejected, backtest_completed, research_failed, budget_exceeded, risk_limit_triggered, system_disconnected. Inbox in-app y adaptadores opcionales email/webhook. Deduplicar alertas y no exponer secretos.
