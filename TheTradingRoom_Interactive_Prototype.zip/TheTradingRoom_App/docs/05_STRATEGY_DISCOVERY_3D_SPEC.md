# 05 — Strategy Discovery: especificación técnica y visual

## Geometría
Sala 14 m X × 10 m Z × 4.2 m Y; origen en centro del suelo; X ±7, Z ±5, Y 0–4.2. Piso grafito, pared trasera sólida, laterales de vidrio oscuro, frente con acceso central de 2 m y cristales, techo ocultable desde cámara overview. Luces LED indirectas y acentos cian, evitar bloom excesivo.

## Mobiliario
3 escritorios 1.8×0.8×0.75 m, 3 sillas ergonómicas low-poly, 6 monitores, Market Radar Wall 10×2 m en muro posterior, Discovery Table circular diámetro 2.2 m central, Research Queue panel lateral derecho, consola de entrada, 8–12 luminarias. Pasillos libres y zonas de clic accesibles.

## Agentes
- A01 Research Director: desk izquierdo; coordinación, asignación y revisión.
- A02 Strategy Hunter: desk derecho; hipótesis y oportunidades.
- A03 Market Regime Analyst: desk inferior izquierdo en planta; régimen, tendencia, rango, volatilidad.
Los avatares deben ser personajes profesionales estilizados y consistentes, con animaciones idle, typing/researching, analyzing, completed, waiting_approval, error. Estados reales del backend.

## Cinco pantallas
1. Market Radar: símbolos, volatilidad, señales preliminares, frescura de datos.
2. Strategy Library: hipótesis, versiones, familias, estados y procedencia.
3. Market Regime: clasificación, confianza, ventana y fuente.
4. Research Queue: trabajos, owner, progreso, errores y reintentos.
5. Discovery Table: mapa de relaciones hipótesis-activos-evidencia.
Cada pantalla 3D abre overlay HTML 2D de alta legibilidad. Mock siempre DEMO.

## Cámaras
Overview ortográfica inicial position [17,15,18], target [0,1,0], zoom aprox 43. Focus a agente/monitor; Presentation frontal a mesa central. Transiciones suaves 450–700 ms, límites de zoom/rotación, tecla Escape, selección mediante raycasting y navegación por teclado.

## Componentes React Three Fiber
`DiscoveryScene`, `DiscoveryRoom`, `RoomGeometry`, `RoomLighting`, `CameraController`, `AnalystDesk`, `OfficeChair`, `DiscoveryTable`, `AgentAvatar`, `AgentAnimations`, `MarketRadar`, `ResearchQueue`, `ScreenSurface`. UI HTML: `DiscoveryHUD`, `AgentInspector`, `ScreenInspector`, `ResearchLauncher`. Hooks: `useRoomNavigation`, `useAgentStatus`, `useResearchEvents`; Zustand `discoveryStore`.

## API/eventos
GET /api/discovery/agents, GET /api/discovery/strategies, POST /api/discovery/research, GET /api/discovery/jobs/{id}, POST /api/discovery/jobs/{id}/cancel, WS /api/discovery/events. Eventos: ROOM_ENTERED, AGENT_SELECTED, SCREEN_SELECTED, RESEARCH_REQUESTED, RESEARCH_STARTED, HYPOTHESIS_CREATED, RESEARCH_COMPLETED, RESEARCH_FAILED, HYPOTHESIS_SUBMITTED. Correlation IDs, idempotencia y auth.

## Pruebas de aceptación
Escena renderizada, 3 agentes, 5 pantallas interactivas, 3 cámaras, HUD, API mock, evento en cola, errores/reconexión, demo identificado, fallback móvil 2D, teclado y rendimiento medido.
