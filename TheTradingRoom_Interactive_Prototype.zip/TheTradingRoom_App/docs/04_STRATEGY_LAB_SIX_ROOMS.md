# 04 — Strategy Lab: las seis salas

## A — Strategy Discovery
Agentes Research Director, Strategy Hunter, Market Regime Analyst. Radar de mercado, biblioteca de hipótesis, régimen, cola de investigación, mesa holográfica. Acciones Find Me a Strategy, crear hipótesis, asignar trabajo.

## B — Algorithm Engineering
Quant Developer. Editor Python, reglas entry/exit/invalidation, pruebas unitarias, Git, sandbox sin secretos, versionado y revisión de código.

## C — Backtesting Center
Backtesting Engineer. Curvas de equity, drawdown, operaciones, costes, slippage, comparativa, métricas (CAGR, Sharpe, Sortino, expectancy, profit factor, OOS, capacidad, turnover). No garantizar rentabilidad.

## D — Validation & Stress Testing
Robustness Analyst y Strategy Critic. Walk-forward, OOS, bootstrap, estrés de volatilidad/spread, sensibilidad, sesgos, overfit, estabilidad por régimen.

## E — Strategy Review Board
Research Director y Strategy Auditor. Panel de evidencia, críticas, controles de riesgo y promoción determinista a paper. Ninguna aprobación a live.

## F — Strategy Vault
Catálogo de hipótesis, versiones, artefactos, resultados, decisiones, experimentos y trazabilidad.

## Funciones distintivas
- Find Me a Strategy: ciclo autónomo/manual de descubrimiento.
- Strategy Tournament: comparar candidatas bajo mismo protocolo, evitar selección oportunista.
- Strategy Mutation Lab: variantes enlazadas a estrategia padre y revalidación obligatoria.
- Market Regime Simulator: probar hipótesis por regímenes.
- Strategy Autopsy: diagnosticar deterioro y fallos.

## Flujo
Discovery -> Engineering -> Backtest -> Validation -> Audit -> Paper Approved -> Paper Active -> Performance Monitoring -> Vault. Cualquier paso puede terminar REJECTED, FAILED, PAUSED o ARCHIVED.
