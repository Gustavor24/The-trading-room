# 06 — Agentes y orquestación autónoma

## 16 roles especializados
1 Chief Trading Officer (coordina); 2 Forex Macro Analyst (tasas y macro); 3 Crypto Market Analyst (microestructura); 4 News Intelligence (noticias); 5 Technical Analyst (niveles y señales); 6 Market Regime Analyst (regímenes); 7 Strategy Hunter (hipótesis); 8 Quant Developer (algoritmos); 9 Backtesting Engineer (histórico); 10 Robustness Auditor (robustez); 11 Signal Supervisor (calidad de señales); 12 Risk Officer (supervisión); 13 Execution Supervisor (monitoreo paper); 14 Portfolio Manager (asignación paper); 15 Performance Analyst (resultados); 16 System Guardian (infraestructura).

## Strategy Lab roles adicionales/funcionales
Research Director, Strategy Critic, Strategy Auditor. Estos roles pueden ser subroles lógicos compartidos, no procesos permanentes. No se requiere 16 instancias LLM ejecutándose 24/7.

## Cadencia y cuotas
Cron `0 */6 * * *` en UTC. Cupo máximo 10 nuevas hipótesis/día UTC, reservado transaccionalmente antes de la creación. Hasta 2 research jobs y 2 backtests concurrentes. Priorización de backlog y alertas; evitar trabajos duplicados por schedule/retry.

## Colas
`discovery`, `data`, `quant`, `validation`, `audit`, `promotion`, `notification`, `dead_letter`. Retry con backoff, timeouts, cancelación, heartbeat, job_id y correlation_id, workers con límites CPU/memoria.

## Deduplicación
Fingerprint de asset_class, mercado, instrumentos, timeframe, familia, reglas normalizadas, entry/exit, parámetros. Comprobación semántica complementaria. Variantes vinculadas con `parent_strategy_id`, no contadas como descubrimientos independientes sin política explícita.

## Budget Manager
Propuesta inicial Claude API: $5/día y $100/mes, límites configurables. No suponer que equivalen a factura máxima de todo el stack. Pausar nuevas investigaciones cuando se alcance límite, pero mantener monitoreo de riesgo.

## Persistencia y reproducibilidad
Tablas: research_cycles, hypothesis_quota, hypotheses, strategies, strategy_versions, datasets, experiments, experiment_metrics, validation_checks, decisions, paper_orders, paper_fills, positions, notifications, audit_events. Cada experimento registra code commit/hash, dataset hash, periodos, availability timestamps, parámetros, costos, seeds, resultados, fallos y revisión.

## Agentes vs determinismo
Claude propone hipótesis, redacta análisis y revisa evidencia. Los engines de backtesting, validación, riesgo y ejecución son software determinista con logs y tests. Prohibido que un LLM envíe órdenes directamente.
