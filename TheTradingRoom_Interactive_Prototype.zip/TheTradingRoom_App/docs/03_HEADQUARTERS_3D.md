# 03 — Headquarters 3D: UX y departamentos

## Estilo
Dark cinematic + oficina financiera profesional; metal grafito, vidrio ahumado, iluminación azul/cian y superficies de trabajo legibles. Paleta #0B1220, #152238, #26364F, #3B82F6, #22D3EE; verde success, ámbar review, rojo error. Tipografía Inter/Geist.

## Ocho departamentos
1. **Executive Command Center**: resumen de mercados, agentes, paper P&L, alertas, presupuestos, kill switch.
2. **Strategy Lab**: seis salas A–F de descubrimiento, ingeniería, backtesting, validación, revisión y vault.
3. **Market Intelligence**: macro Forex, estructura Crypto, noticias, análisis técnico y régimen.
4. **Trading Floor**: señales, paper orders, fills, posiciones, errores y reconciliación.
5. **Risk & Compliance**: límites, exposición, concentración, drawdown, permisos y auditoría.
6. **Portfolio Management**: capital paper, atribución, performance por estrategia/mercado.
7. **Systems Operations**: health de proveedores, latencia, errores, colas, incidentes.
8. **Research Archive**: experimentos, código, datasets, decisiones, reportes, postmortems.

## Navegación
Explore: cámara isométrica, click para foco, transición 450–700 ms, minimapa, teletransporte entre salas, tooltips y panel Agent Inspector. Operate: dashboards 2D para tablas, gráficos y operaciones detalladas. Teclado/escape, accesibilidad, móvil 2D prioritario.

## Avatares
Estados `idle`, `researching`, `analyzing`, `completed`, `waiting_approval`, `error`. Señales de color y animación de bajo costo, vinculadas a eventos del backend; jamás fingir actividad live cuando se usa mock.

## Performance
GLB/GLTF comprimido, lazy loading por sala, instancing, LOD, limitar bloom, DPR adaptable, fallback WebGL, reduce-motion, control de FPS. Objetivo aspiracional 60 fps desktop / 30 móvil, verificar por hardware.
