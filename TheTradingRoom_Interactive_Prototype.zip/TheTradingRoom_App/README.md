# The Trading Room — Interactive Headquarters Prototype

Aplicación web interactiva, adaptable a iPhone y escritorio, con ocho departamentos, seis salas del Strategy Lab, directorio de 16 agentes, inspector de salas y simulador local de hipótesis.

## Cómo abrir

Abre `index.html` en un navegador de escritorio. Para una experiencia fiable en iPhone, publica esta carpeta en un alojamiento estático HTTPS (GitHub Pages, Netlify o Vercel) y abre su URL desde Safari. También puedes ejecutar localmente:

```bash
python3 -m http.server 8000
```

Luego visita `http://localhost:8000`. En iPhone, después de publicar con HTTPS, Safari → Compartir → Añadir a pantalla de inicio.

## Qué funciona hoy

- Navegación por 8 departamentos y sus monitores.
- Plano interactivo de la sede en SVG isométrico; **no es todavía un motor 3D WebGL**.
- 6 salas del Strategy Lab seleccionables.
- Inspector con detalles de departamentos, salas y agentes.
- 16 perfiles de agentes.
- Botón Find Me a Strategy: crea **hipótesis DEMO**, guardadas localmente en el navegador.
- Vista de pipeline, limpieza de simulaciones, diseño responsive y modo instalable básico.
- Configuración YAML, documentación de arquitectura y prohibición de live trading.

## Qué NO funciona todavía

- No se ejecuta Claude API ni agentes autónomos.
- No hay scheduler de seis horas ejecutándose, backtesting real ni promoción paper.
- No se conecta a OANDA, Kraken ni ningún broker.
- No hay cotizaciones reales ni operaciones.
- No hay backend ni almacenamiento compartido; localStorage es sólo del navegador.
- La escena es una ilustración isométrica SVG interactiva, no un mundo 3D con cámara libre.

## Próximos hitos

1. Migrar escena a React Three Fiber/Three.js con cámara, avatares y colisiones.
2. Implementar FastAPI/PostgreSQL/Redis/Celery y scheduler persistente.
3. Integrar feeds de mercado y motor de backtesting reproducible.
4. Agentes Claude API con sandbox, presupuestos y auditoría.
5. Promotion Gate determinista y paper trading aislado.
6. Despliegue HTTPS con autenticación y observabilidad.

**Seguridad:** trading real deshabilitado. No coloques secretos en el frontend.
