# CLAUDE.md — Instrucciones permanentes

Este repositorio es **The Trading Room**, AI Trading Headquarters 3D. Lee README y todos los archivos docs antes de tomar decisiones estructurales.

## Requisitos innegociables
- Forex y Crypto, day trading y swing trading.
- Investigación autónoma a las 00:00, 06:00, 12:00 y 18:00 UTC; máximo 10 hipótesis nuevas por día UTC, cuota transaccional.
- Auto-promoción únicamente a PAPER tras gates de validación deterministas y auditables.
- Notificaciones habilitadas.
- `live_trading_enabled: false`; NO implementar endpoints de producción, NO usar credenciales live, NO permitir que un LLM habilite live.
- Distinguir datos simulados, históricos y reales; no inventar cotizaciones, órdenes, ganancias ni tests.
- Investigación con Claude API; cálculos cuantitativos, reglas de riesgo y ejecución en código independiente.
- Código generado ejecutado en sandbox sin secretos ni red abierta.
- No modificar archivos existentes sin inspeccionarlos; mantener changelog y tests.

## Primer paso
Inspeccionar el repositorio; entregar plan de implementación con dependencias, riesgos y pruebas. Después construir un vertical slice de Strategy Discovery 3D con mocks y eventos. No afirmar que algo funciona sin ejecutarlo y verificarlo.

## Fuentes de verdad
`docs/10_DECISIONS_AND_OPEN_ITEMS.md` diferencia decisiones aprobadas de propuestas. `config/autonomous_strategy_lab.yaml` contiene parámetros iniciales. Si hay conflicto, explicar y pedir confirmación antes de ampliar riesgos.
